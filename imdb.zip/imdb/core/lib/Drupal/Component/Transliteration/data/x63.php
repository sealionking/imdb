<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'bai', 'chi', 'gua', 'zhi', 'kuo', 'duo', 'duo', 'zhi', 'qie', 'an', 'nong', 'zhen', 'ge', 'jiao', 'kua', 'dong',
  0x10 => 'na', 'tiao', 'lie', 'zha', 'lu', 'die', 'wa', 'jue', 'lie', 'ju', 'zhi', 'luan', 'ya', 'wo', 'ta', 'xie',
  0x20 => 'nao', 'dang', 'jiao', 'zheng', 'ji', 'hui', 'xian', 'yu', 'ai', 'tuo', 'nuo', 'cuo', 'bo', 'geng', 'ti', 'zhen',
  0x30 => 'cheng', 'sa', 'sa', 'keng', 'mei', 'long', 'ju', 'peng', 'jian', 'yi', 'ting', 'shan', 'rua', 'wan', 'xie', 'cha',
  0x40 => 'feng', 'jiao', 'wu', 'jun', 'jiu', 'tong', 'kun', 'huo', 'tu', 'zhuo', 'pou', 'lu', 'ba', 'han', 'shao', 'nie',
  0x50 => 'juan', 'ze', 'shu', 'ye', 'jue', 'bu', 'wan', 'bu', 'zun', 'yi', 'zhai', 'lu', 'sou', 'tuo', 'lao', 'sun',
  0x60 => 'bang', 'jian', 'huan', 'dao', 'wei', 'wan', 'qin', 'peng', 'she', 'lie', 'min', 'men', 'fu', 'bai', 'ju', 'dao',
  0x70 => 'wo', 'ai', 'juan', 'yue', 'zong', 'chen', 'chui', 'jie', 'tu', 'ben', 'na', 'nian', 'ruo', 'zuo', 'wo', 'xi',
  0x80 => 'xian', 'cheng', 'dian', 'sao', 'lun', 'qing', 'gang', 'duo', 'shou', 'diao', 'pou', 'di', 'zhang', 'hun', 'ji', 'tao',
  0x90 => 'qia', 'qi', 'pai', 'shu', 'qian', 'ling', 'ye', 'ya', 'jue', 'zheng', 'liang', 'gua', 'yi', 'huo', 'shan', 'zheng',
  0xA0 => 'e', 'cai', 'tan', 'che', 'bing', 'jie', 'ti', 'kong', 'tui', 'yan', 'cuo', 'zhou', 'ju', 'tian', 'qian', 'ken',
  0xB0 => 'bai', 'pa', 'jie', 'lu', 'guai', 'ming', 'geng', 'zhi', 'dan', 'meng', 'can', 'sao', 'guan', 'peng', 'yuan', 'nuo',
  0xC0 => 'jian', 'zheng', 'jiu', 'jian', 'yu', 'yan', 'kui', 'nan', 'hong', 'rou', 'pi', 'wei', 'sai', 'zou', 'xuan', 'miao',
  0xD0 => 'ti', 'nie', 'cha', 'shi', 'zong', 'zhen', 'yi', 'xun', 'yong', 'bian', 'yang', 'huan', 'yan', 'zan', 'an', 'xu',
  0xE0 => 'ya', 'wo', 'ke', 'chuai', 'ji', 'ti', 'la', 'la', 'chen', 'kai', 'jiu', 'jiu', 'tu', 'jie', 'hui', 'gen',
  0xF0 => 'chong', 'xiao', 'die', 'xie', 'yuan', 'qian', 'ye', 'cha', 'zha', 'bei', 'yao', 'wei', 'beng', 'lan', 'wen', 'qin',
];
